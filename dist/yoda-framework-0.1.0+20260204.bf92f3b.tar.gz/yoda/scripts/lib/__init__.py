"""Shared helpers for YODA scripts."""
